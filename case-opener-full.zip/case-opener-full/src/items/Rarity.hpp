#pragma once

#include <SFML/Graphics/Color.hpp>
#include <string>
#include <array>

// ── Rarity ────────────────────────────────────────────────────────────────────
// 7-tier rarity system inspired by CS-style case openers.
// Ordered from most common (Consumer) to rarest (Contraband).
// ─────────────────────────────────────────────────────────────────────────────
enum class Rarity : int
{
    Consumer    = 0,   // grey
    Industrial  = 1,   // light blue
    MilSpec     = 2,   // blue
    Restricted  = 3,   // purple
    Classified  = 4,   // pink / rose
    Covert      = 5,   // red
    Contraband  = 6    // gold — ultra rare ★
};

// ── RarityMeta ────────────────────────────────────────────────────────────────
// All display data for a rarity tier in one place.
struct RarityMeta
{
    const char* name;           // e.g. "Covert"
    sf::Color   color;          // accent colour used in UI
    float       dropWeight;     // relative probability weight (not normalised)
    float       baseValueMulti; // base item-value multiplier before wear
};

// ── rarityData ────────────────────────────────────────────────────────────────
// Indexed by static_cast<int>(Rarity::*).
// Drop weights roughly mirror CS2 odds:
//   Consumer ~79.9 %, Industrial ~15.98 %, MilSpec ~3.2 %,
//   Restricted ~0.64 %, Classified ~0.128 %, Covert ~0.026 %, Contraband ~0.004 %
inline constexpr std::array<RarityMeta, 7> rarityData
{{
    // name           colour (R,G,B)           weight    baseMulti
    { "Consumer",   { 176, 195, 217 },         79.92f,   1.0f   },  // grey-blue
    { "Industrial", { 94,  152, 217 },         15.98f,   2.5f   },  // light blue
    { "Mil-Spec",   { 75,  105, 255 },          3.20f,   8.0f   },  // blue
    { "Restricted", { 136,  71, 255 },          0.64f,  25.0f   },  // purple
    { "Classified", { 211,  44, 230 },          0.128f, 80.0f   },  // pink
    { "Covert",     { 235,  75,  75 },          0.026f, 250.0f  },  // red
    { "Contraband", { 228, 174,  57 },          0.004f, 800.0f  },  // gold
}};

// ── Helper free functions ─────────────────────────────────────────────────────

inline const RarityMeta& getRarityMeta(Rarity r)
{
    return rarityData[static_cast<int>(r)];
}

inline const char* rarityName(Rarity r)
{
    return getRarityMeta(r).name;
}

inline sf::Color rarityColor(Rarity r)
{
    return getRarityMeta(r).color;
}

inline float rarityDropWeight(Rarity r)
{
    return getRarityMeta(r).dropWeight;
}

inline float rarityBaseValueMultiplier(Rarity r)
{
    return getRarityMeta(r).baseValueMulti;
}

// Total weight sum (used by the drop roller to normalise).
inline float totalRarityWeight()
{
    float sum = 0.f;
    for (const auto& m : rarityData) sum += m.dropWeight;
    return sum;
}
